﻿using System;

namespace Elliot.Infra.Configuration
{
    public abstract class SettingsBase : AppSettingsBase, ISettingsBase
    {
        protected SettingsBase(string prefix = "") : base(prefix)
        {
            
        }
 

        public string LogPath
        {
            get { return GetValue(() => LogPath, GetGlobalValue(() => LogPath)); }
        }

        public string LogArchivePath
        {
            get { return GetValue(() => LogArchivePath, GetGlobalValue(() => LogArchivePath)); }
        }

        public string LogFilename => GetType().Name.Replace("Settings", string.Empty) + ".log";

        public bool LogAllMessages
        {
            get { return GetValue(() => LogAllMessages, GetGlobalValue(() => LogAllMessages)); }
        }
    }
}
