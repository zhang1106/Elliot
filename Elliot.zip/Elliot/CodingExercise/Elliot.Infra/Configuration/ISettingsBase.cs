﻿namespace Elliot.Infra.Configuration
{
    public interface ISettingsBase
    {
        string LogPath { get; }
        string LogFilename { get; }
        string LogArchivePath { get; }
    }
}
