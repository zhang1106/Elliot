﻿namespace Elliot.Infra.Hosting
{
    public interface IService
    {
        string Name { get; }
        void Start();
        void Stop();
    }
}
