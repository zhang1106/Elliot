using System;
using System.Collections.Generic;
using System.Linq;
using Elliot.Infra.Hosting;
using Elliot.ApiGateway.Http;
using StructureMap;
using System.Web.Http.Dependencies;
using Elliot.Business;

namespace Elliot.ApiGateway
{
    public class CompositionRoot : ICompositionRoot<IService>
    {
        private readonly IContainer _container;
        private readonly ApiGatewaySettings _settings;

        protected static CompositionRoot SvcComposite;

        public static CompositionRoot CompositeRootInstanace()
        {
            return SvcComposite ?? (SvcComposite = new CompositionRoot());
        }

        public CompositionRoot()
        {
            _settings = new ApiGatewaySettings();
            _container = new Container(
                    config =>
                    {
                        ConfigureRest(config, _settings);
                        config.For<IThreadSafeSvc>().Use<ThreadSafeService>().Singleton();
                        config.For<ITradeService>().Use<TradeService>();
                        config.For<IAllocationService>().Use<AllocationService>()
                        .Ctor<int>().Is(_settings.FundAThreshold)
                        .Singleton();
                        config.For<IIdService>().Use<IdService>();
                        config.For<IDatabaseSvc>().Use<DatabaseSvc>();
                    }
                );

            _container.Inject(typeof(IDependencyResolver), new StructureMapDependencyResolver(_container));
        }
       
        private void ConfigureRest(ConfigurationExpression config, ApiGatewaySettings settings)
        {
            var httpConfig = config.ForConcreteType<HttpServiceOptions>().Configure
                .Ctor<string>().Is(settings.Http.BaseUrl)
                .Setter(m => m.DependencyResolver).IsTheDefault()
                .Setter(m => m.AllowTokenAsUrlParameter).Is(settings.Http.AllowTokenAsUrlParameter);

            config.For<IService>().Add<HttpService>()
                .Named(nameof(HttpService))
                .Ctor<HttpServiceOptions>().Is(httpConfig);
            
            config
               .ForConcreteType<ApiGatewayService>().Configure
               .Ctor<IService>("httpService").Is(ctx => ctx.GetInstance<IService>(nameof(HttpService)));

           
        }
      
        public IService Initialize()
        {
            var svc = _container.GetInstance<IService>();
            return svc;
        }

        public void Dispose()
        { }

        private class StructureMapDependencyResolver : IDependencyResolver
        {
            private readonly IContainer _container;

            public StructureMapDependencyResolver(IContainer container)
            {
                _container = container;
            }

            public void Dispose()
            {
                // nothing
            }

            public object GetService(Type serviceType)
            {
                return   _container.TryGetInstance(serviceType);
            }

            public IEnumerable<object> GetServices(Type serviceType)
            {
                return _container.GetAllInstances(serviceType).Cast<object>();
            }

            public IDependencyScope BeginScope()
            {
                return new StructureMapDependencyScope(_container.GetNestedContainer());
            }

            private class StructureMapDependencyScope : IDependencyScope
            {
                private readonly IContainer _container;

                public StructureMapDependencyScope(IContainer container)
                {
                    _container = container;
                }

                public void Dispose()
                {
                    _container.Dispose();
                }

                public object GetService(Type serviceType)
                {
                    return   _container.GetInstance(serviceType);
                }

                public IEnumerable<object> GetServices(Type serviceType)
                {
                    return _container.GetAllInstances(serviceType).Cast<object>();
                }
            }
        }
    }
}
