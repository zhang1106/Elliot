﻿using Elliot.ApiGateway.Http;
using Elliot.Infra.Configuration;

namespace Elliot.ApiGateway
{
    public class ApiGatewaySettings : SettingsBase
    {
        public ApiGatewaySettings(): base("ApiGateway.")
        {}
        
        public HttpSettings Http { get; } = new HttpSettings();

        public int FundAThreshold {  get { return GetValue(() => FundAThreshold); } }
    }
}
