﻿using System.Web.Http.Dependencies;
using Microsoft.Owin.Hosting;

namespace Elliot.ApiGateway.Http
{
    public class HttpServiceOptions : StartOptions
    {
        public HttpServiceOptions(string baseUrl)
            : base(baseUrl)
        {
            
        }
        
        public IDependencyResolver DependencyResolver { get; set; }
      
        public bool AllowTokenAsUrlParameter { get; set; }
    }
}
