﻿using Elliot.Infra.Configuration;

namespace Elliot.ApiGateway.Http
{
    public class HttpSettings : AppSettingsBase
    {
        public HttpSettings() : base ("ApiGateway.Http.")
        {
            
        }

        public string BaseUrl
        {
            get { return GetValue(() => BaseUrl, "http://localhost:9777"); }
        }

        public bool AllowTokenAsUrlParameter
        {
            get { return GetValue(() => AllowTokenAsUrlParameter, true); }
        }
    }
}
