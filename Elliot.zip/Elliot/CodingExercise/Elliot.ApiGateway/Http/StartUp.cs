﻿using System.Web.Http;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Security.OAuth;
using Owin;
using Owin.Security.AesDataProtectorProvider;

namespace Elliot.ApiGateway.Http
{
    public class StartUp
    {
        private readonly HttpServiceOptions _options;

        public StartUp(HttpServiceOptions options)
        {
            _options = options;
        }

        public void Configuration(IAppBuilder appBuilder)
        {
            
            var http = new HttpConfiguration();
            http.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{key}",
                defaults: new {key = RouteParameter.Optional});

            http.SuppressDefaultHostAuthentication();
            http.Filters.Add(new HostAuthenticationFilter(OAuthDefaults.AuthenticationType));
            

            http.Formatters.Clear();
            http.Formatters.Add(new JsonNetFormatter());
            http.DependencyResolver = _options.DependencyResolver;
         

            appBuilder.UseCors(CorsOptions.AllowAll);
            appBuilder.UseAesDataProtectorProvider();
            appBuilder.UseWebApi(http);



            SwaggerConfig.Register(http);
        }

    }
}
