﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Elliot.ApiGateway.Http.Model;
using Elliot.Business;
using Elliot.Business.Model;

namespace Elliot.ApiGateway.Http.Controller
{
    public class TradeController: ApiController
    {
        private readonly IThreadSafeSvc _threadSafeSvc;

        public TradeController(IThreadSafeSvc threadSafeSvc)
        {
            _threadSafeSvc = threadSafeSvc;
        }

        /// <summary>
        /// enum TransactionTypeEnum
        ///{ Buy, Sell}
        /// enum AssetTypeEnum
        ///{Equity,Future}
        /// </summary>
        /// <param name="trade"></param>
        [HttpPost]
        public string Post([FromBody]NewTrade trade)
        {
            _threadSafeSvc.Add(trade.Security, trade.Amount,trade.Price,trade.TransactionType);
            return "OK";
        }

        [HttpPost]
        public string Update([FromBody] AmendTrade trade)
        {
            var rslt = _threadSafeSvc.UpdateTrade(trade.TradeId, trade.Amount, trade.Price);
            return rslt ? "OK" : "FAIL";
        }

        [HttpGet]
        public IList<Trade> GetAll()
        {
            return _threadSafeSvc.GetAllTrades().ToList();
        }

        [HttpGet]
        public Trade Get(string tradeId)
        {
            return _threadSafeSvc.GetTrade(tradeId);
        }
    }
}
