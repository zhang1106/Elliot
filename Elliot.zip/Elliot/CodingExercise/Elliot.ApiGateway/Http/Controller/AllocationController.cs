﻿using System.Collections.Generic;
using System.Web.Http;
using Elliot.Business;
using Elliot.Business.Model;

namespace Elliot.ApiGateway.Http.Controller
{
    public class AllocationController : ApiController
    {
        private readonly IThreadSafeSvc _threadSafeSvc;

        public AllocationController(IThreadSafeSvc threadSafeSvc)
        {
            _threadSafeSvc = threadSafeSvc;
        }

        /// <summary>
        /// enum TransactionTypeEnum
        ///{ Buy, Sell}
        /// enum AssetTypeEnum
        ///{Equity,Future}
        /// </summary>
        /// <param name="trades"></param>
        [HttpPost]
        public string Allocate(IList<string> trades)
        {
            _threadSafeSvc.Allocatate(trades);
            return "OK";
        }

        [HttpGet]
        public Dictionary<string, Allocation> GatAll()
        {
            return _threadSafeSvc.GetAllocations();
        }

        [HttpGet]
        public Allocation Get(string symbol)
        {
            return _threadSafeSvc.GetAllocation(symbol);
        }
    }
}
