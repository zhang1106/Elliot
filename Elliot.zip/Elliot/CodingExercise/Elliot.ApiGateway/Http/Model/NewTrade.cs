﻿using Elliot.Business.Model;

namespace Elliot.ApiGateway.Http.Model
{
    public class NewTrade
    {
        public Security Security { get; set; }
        public decimal Price { get; set; }
        public decimal Amount { get; set; }
        public TransactionTypeEnum TransactionType { get; set; }
    }
}
