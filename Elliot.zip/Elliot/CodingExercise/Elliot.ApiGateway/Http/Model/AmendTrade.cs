﻿namespace Elliot.ApiGateway.Http.Model
{
    public class AmendTrade
    {
        public string TradeId { get; set; }
        public decimal Amount { get; set; }
        public decimal Price { get; set; }
    }
}
