﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public class TradeService : ITradeService
    {
        private readonly Dictionary<string, Trade> _trades;
        private readonly IIdService _idService;
        private readonly IDatabaseSvc _databaseSvc;

        public TradeService(IIdService idService, IDatabaseSvc databaseSvc)
        {
            _trades = new Dictionary<string, Trade>();
            _idService = idService;
            _databaseSvc = databaseSvc;
        }

        public void Add(Security security, decimal amt, decimal price, TransactionTypeEnum side)
        {
            var trade = new Trade()
            {
                Security = security,
                Amount = amt,
                Price = price,
                TradeId = _idService.GetNewId(),
                AllocationStatus = AllocationStatusEnum.NotAllocated,
                TransactionType = side
            };
            _trades.Add(trade.TradeId, trade);
            _databaseSvc.Save(trade);
        }

        public bool Update(Trade trade)
        {
            if (trade.AllocationStatus == AllocationStatusEnum.Allocated)
            {
                return false;
            }
            _trades[trade.TradeId] = trade;
            _databaseSvc.Save(trade);
            return true;
        }

        public Trade GetTrade(string tradeId)
        {
            return _trades.ContainsKey(tradeId) ? _trades[tradeId] : null;
        }

        public IEnumerable<Trade> GetAllTrades()
        {
            return _trades.Values;
        }
    }
}
