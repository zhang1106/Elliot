﻿namespace Elliot.Business.Model
{
    public class Fund
    {
        public string Name { get; set; }
        public decimal Amount { get; set; }
    } 
}
