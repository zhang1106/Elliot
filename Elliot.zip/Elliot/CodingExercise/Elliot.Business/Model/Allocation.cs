﻿namespace Elliot.Business.Model
{
    public class Allocation
    {
        public Fund FundA { get; set; }
        public Fund FundB { get; set; }
    }
}
