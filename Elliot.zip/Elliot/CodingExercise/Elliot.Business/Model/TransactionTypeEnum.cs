﻿namespace Elliot.Business.Model
{
    public enum TransactionTypeEnum
    {
        Buy,
        Sell
    }
}
