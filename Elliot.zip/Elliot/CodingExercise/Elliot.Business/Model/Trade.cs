﻿using System.Collections.Generic;

namespace Elliot.Business.Model
{
    public class Trade
    {
        public string TradeId { get; set; }
        public Security Security { get; set; }
        public decimal Price { get; set; }
        public decimal Amount { get; set; }
        public TransactionTypeEnum TransactionType { get; set; }
        public AllocationStatusEnum AllocationStatus { get; set; }
        public IList<Allocation> Allocations { get; set; }
    }
}
