﻿namespace Elliot.Business.Model
{
    public enum  AllocationStatusEnum
    {
        NotAllocated,
        Allocated
    }
}
