﻿namespace Elliot.Business.Model
{
    public class Security
    {
        public AssetTypeEnum AssetType { get; set; }
        public string Symbol { get; set; }
    }
}
