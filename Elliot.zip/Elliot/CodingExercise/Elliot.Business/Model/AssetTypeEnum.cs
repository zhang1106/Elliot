﻿namespace Elliot.Business.Model
{
    public enum AssetTypeEnum
    {
        Equity,
        Future
    } 
    
}
