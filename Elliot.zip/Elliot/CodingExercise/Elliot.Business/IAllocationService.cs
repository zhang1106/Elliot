﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public interface IAllocationService
    {
        void Allocate(IList<Trade> trades);
        Dictionary<string, Allocation> GetAllocations();
        Allocation GetAllocation(string symbol);
    }
}
