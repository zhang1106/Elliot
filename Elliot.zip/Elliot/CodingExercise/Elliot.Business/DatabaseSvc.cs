﻿namespace Elliot.Business
{
    public class DatabaseSvc : IDatabaseSvc
    {
        public void Save<T>(T t)
        {
            //not implementend
        }
    }
}
