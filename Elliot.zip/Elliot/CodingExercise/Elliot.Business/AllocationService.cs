﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public class AllocationService : IAllocationService
    {
        private readonly Dictionary<string, Allocation> _securityAllocation;
        private readonly decimal _allocationThreshold;
        private const string FundA = "Fund A";
        private const string FundB = "Fund B";
        private readonly IDatabaseSvc _databaseSvc;

        public AllocationService(int fundAThreshold, IDatabaseSvc databaseSvc)
        {
            _allocationThreshold = fundAThreshold;
            _databaseSvc = databaseSvc;
            _securityAllocation = new Dictionary<string, Allocation>();
        }

        public void Allocate(IList<Trade> trades)
        {
            foreach (var t in trades)
            {
                if (t.AllocationStatus == AllocationStatusEnum.Allocated)
                {
                    continue;
                }

                var tradeAmount = t.Amount * t.Price * (t.TransactionType == TransactionTypeEnum.Buy ? 1 : -1);
               
                var fundARatio = t.Security.AssetType == AssetTypeEnum.Equity ? 0.2m : 0.3m;
                
                var allocatedToA = tradeAmount * fundARatio;
                var allocatedToB = tradeAmount - allocatedToA;

                
                Allocation allocation;
                _securityAllocation.TryGetValue(t.Security.Symbol, out allocation);

                allocation = allocation ??
                                new Allocation() { FundA = new Fund(){Name=FundA}, FundB = new Fund(){Name=FundB} };

                if (t.Security.AssetType == AssetTypeEnum.Future)
                {
                    allocation.FundA.Amount += allocatedToA;
                    allocation.FundB.Amount += allocatedToB;
                }
                else  
                {
                    if (t.TransactionType == TransactionTypeEnum.Sell &&
                        allocation.FundA.Amount >= _allocationThreshold
                    )
                    {
                        var overAlloc = allocation.FundB.Amount - allocation.FundA.Amount * 4;
                        var firstAlloc = tradeAmount + overAlloc;
                        allocatedToA = firstAlloc>=0? 0: firstAlloc * fundARatio;
                        allocatedToB = tradeAmount - allocatedToA;
                    }
                    else
                    {
                        if (allocation.FundA.Amount + allocatedToA > _allocationThreshold)
                        {
                            allocatedToA = _allocationThreshold - allocation.FundA.Amount;
                        }
                        allocatedToB = tradeAmount - allocatedToA;
                    }

                    allocation.FundA.Amount += allocatedToA;
                    allocation.FundB.Amount += allocatedToB;
                }
                _securityAllocation[t.Security.Symbol] = allocation;
                t.AllocationStatus = AllocationStatusEnum.Allocated;
                t.Allocations=new List<Allocation>(){new Allocation(){FundA=new Fund(){Name=FundA,Amount=allocatedToA}, FundB=new Fund(){Name=FundB, Amount=allocatedToB}}};
                _databaseSvc.Save(allocation);
                _databaseSvc.Save(t);
               
            }
        }

        public Dictionary<string, Allocation> GetAllocations()
        {
            return _securityAllocation;
        }

        public Allocation GetAllocation(string symbol)
        {
            Allocation alloc;
            return _securityAllocation.TryGetValue(symbol, out alloc) ? alloc : null;
        }
    }
}
