﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public class ThreadSafeService : IThreadSafeSvc
    {
        private readonly ITradeService _tradeService;
        private readonly IAllocationService _allocationService;
        private readonly ReaderWriterLockSlim _lock; 

        public ThreadSafeService(ITradeService tradeService, IAllocationService allocationService)
        {
            _tradeService = tradeService;
            _allocationService = allocationService;
            _lock = new ReaderWriterLockSlim();
        }

        public void Allocatate(IList<string> tradeIds)
        {
            _lock.EnterWriteLock();
            try
            {
                var trades = tradeIds.Select(id => _tradeService
                    .GetTrade(id)).Where(t => t != null).ToList();
                _allocationService.Allocate(trades);
            }
            finally
            {
                _lock.ExitWriteLock();
            }

        }

        public Dictionary<string, Allocation> GetAllocations()
        {
            _lock.EnterReadLock();
            try
            {
                return _allocationService.GetAllocations();
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }

        public Allocation GetAllocation(string symbol)
        {
            _lock.EnterReadLock();
            try
            {
                return _allocationService.GetAllocation(symbol);
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }

        public void Add(Security security, decimal amt, decimal price, TransactionTypeEnum side)
        {
            _lock.EnterWriteLock();
            try
            {
                _tradeService.Add(security, amt, price, side);
            }
            finally
            {
                _lock.ExitWriteLock();
            }
        }

        public bool UpdateTrade(string tradeId, decimal amount, decimal price)
        {
            _lock.EnterWriteLock();
            try
            {
                var trade = _tradeService.GetTrade(tradeId);
                if (trade?.AllocationStatus != AllocationStatusEnum.NotAllocated)
                {
                    return false;
                }

                trade.Amount = amount;
                trade.Price = price;
                _tradeService.Update(trade);
                return true;
            }
            finally
            {
                _lock.ExitWriteLock();
            }
        }

        public Trade GetTrade(string id)
        {
            _lock.EnterReadLock();
            try
            {
                return _tradeService.GetTrade(id);
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }

        public IEnumerable<Trade> GetAllTrades()
        {
            _lock.EnterReadLock();
            try
            {
                return _tradeService.GetAllTrades();
            }
            finally
            {
                _lock.ExitReadLock();
            }
        }

        ~ThreadSafeService()
        {
            _lock?.Dispose();
        }
    }
}
