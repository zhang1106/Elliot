﻿namespace Elliot.Business
{
    public interface IDatabaseSvc
    {
        void Save<T>(T t);
    }
}
