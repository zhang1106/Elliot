﻿using System.Collections.Generic;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public interface ITradeService
    {
        void Add(Security security, decimal amt, decimal price, TransactionTypeEnum side);
        bool Update(Trade trade);
        Trade GetTrade(string tradeId);
        IEnumerable<Trade> GetAllTrades();
    }
}
