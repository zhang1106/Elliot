﻿using System;

namespace Elliot.Business
{
    public class IdService : IIdService
    {
        public string GetNewId()
        {
            return Guid.NewGuid().ToString();
        }
    }
}
