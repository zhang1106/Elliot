﻿using System.Collections.Generic;
using Elliot.Business.Model;

namespace Elliot.Business
{
    public interface IThreadSafeSvc
    {
        void Allocatate(IList<string> trades);
        Dictionary<string, Allocation> GetAllocations();
        Allocation GetAllocation(string symbol);
        void Add(Security security, decimal amt, decimal price, TransactionTypeEnum side);
        bool UpdateTrade(string tradeId, decimal amount, decimal price);
        Trade GetTrade(string tradeId);
        IEnumerable<Trade> GetAllTrades();

    }
}
