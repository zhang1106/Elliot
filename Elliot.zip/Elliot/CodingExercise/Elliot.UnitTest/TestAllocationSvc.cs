﻿using System.Collections.Generic;
using Elliot.Business.Model;
using Elliot.Business;
using NUnit.Framework;

namespace Elliot.UnitTest
{
    [TestFixture]
    public class TestAllocationSvc
    {
        [TestCase(AssetTypeEnum.Future, "AFut", 100, 100, TransactionTypeEnum.Buy, 3000, 7000)]
        [TestCase(AssetTypeEnum.Future, "AFut", 100, 100, TransactionTypeEnum.Sell, -3000, -7000)]
        [TestCase(AssetTypeEnum.Equity, "A", 100, 100, TransactionTypeEnum.Buy, 2000, 8000)]
        [TestCase(AssetTypeEnum.Equity, "A", 100, 100, TransactionTypeEnum.Sell, -2000, -8000)]
        [TestCase(AssetTypeEnum.Equity, "A", 1000, 130000, TransactionTypeEnum.Buy, 20000000, 110000000)]

        public void TestAllocation(AssetTypeEnum assetType, string symbol, decimal price, decimal amt, TransactionTypeEnum side, decimal expectedA, decimal expectedB)
        {
            var allocationSvc = new AllocationService(20000000, new DatabaseSvc());
            var trade = new Trade()
            {
                Security = new Security() {AssetType = assetType, Symbol = symbol},
                Amount = amt,
                Price = price,
                TransactionType = side,
            };
            allocationSvc.Allocate(new List<Trade>(){trade});
            var alloc = allocationSvc.GetAllocation(trade.Security.Symbol);
            Assert.AreEqual(expectedA,alloc.FundA.Amount);
            Assert.AreEqual(expectedB,alloc.FundB.Amount);
        }

        [TestCase("A", 100, 100, TransactionTypeEnum.Buy, 20000000, 180010000)]
        [TestCase("A", 10, 1000000, TransactionTypeEnum.Sell, 20000000, 170000000)]
        [TestCase("A", 100, 1000000, TransactionTypeEnum.Sell, 20000000, 80000000)]
        [TestCase("A", 150, 1000000, TransactionTypeEnum.Sell, 10000000, 40000000)]
        [TestCase("B", 100, 100, TransactionTypeEnum.Buy, 2000, 8000)]
        public void TestSpecialEqAllocation(string symbol, decimal price, decimal amt, TransactionTypeEnum side, decimal expectedA, decimal expectedB)
        {
            var allocationSvc = new AllocationService(20000000, new DatabaseSvc());
            var security = new Security() { AssetType = AssetTypeEnum.Equity, Symbol = "A" };
            var trade0 = new Trade()
            {
                Security = security,
                Amount = 100000,
                Price = 2000,
                TransactionType = TransactionTypeEnum.Buy
            };
            allocationSvc.Allocate(new List<Trade>() { trade0 });

            security.Symbol = symbol;
            var trade = new Trade()
            {
                Security = security,
                Amount = amt,
                Price = price,
                TransactionType = side,
            };

            allocationSvc.Allocate(new List<Trade>() { trade });

            var alloc = allocationSvc.GetAllocation(security.Symbol);
            Assert.AreEqual(expectedA, alloc.FundA.Amount);
            Assert.AreEqual(expectedB, alloc.FundB.Amount);
        }
    }
}
